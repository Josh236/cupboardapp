import React, {Component} from 'react';

const Layout = {
  standard: 30,
  tall: 40,
};

export default Layout;
