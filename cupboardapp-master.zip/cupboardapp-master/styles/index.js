import React, { Component } from 'react';
import { View, Text } from 'react-native';

class index extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    return (
      <View>
        <Text> index </Text>
      </View>
    );
  }
}

export default index;
