import React from 'react';

const Colors = {
  black: '#05080D',

  white: '#ffffff',

  offWhite: '#FAF7F2',

  grey: '#6f7073',

  lavender: '#9caaed',

  aqua: '#7bcdc8',

  peach: '#f3ad9f',
};

export default Colors;
