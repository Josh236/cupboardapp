import React from 'react';

const Typography = {
  titleBold: 'SourceSansPro-Bold',

  titleRegular: 'SourceSansPro-Regular',

  bodyBold: 'OpenSans-Bold',

  bodyRegular: 'OpenSans-Regular',
};

export default Typography;
