// import {ADD_TITLE} from '../actiontypes/actionTypes';

// export const addtitle = content => {
//     return (dispatch, getState) => {
//         dispatch({type: ADD_TITLE, content})
//     }
//   };
